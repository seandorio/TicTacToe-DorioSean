﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Text.Json;
using System;
using System.Linq;
using TicTacToe_SeanDorio.Models;

namespace TicTacToe_SeanDorio.Controllers
{
    public class GameController : Controller
    {
        private const string SessionKey = "GameState";
        private const string PlayerSymbolKey = "PlayerSymbol";
        private const string ScoreKeyX = "ScoreX";
        private const string ScoreKeyO = "ScoreO";
        private const string GameModeKey = "GameMode"; // Store game mode (AI or Multiplayer)
        private const string AIPlayerKey = "AIPlayer"; // Store AI symbol (X or O)

        public IActionResult Index()
        {
            Console.WriteLine("🔹 GameController: Index() executed"); // Debug Log

            if (string.IsNullOrEmpty(HttpContext.Session.GetString(PlayerSymbolKey)))
            {
                Console.WriteLine("⚠️ No Player Symbol Found! Redirecting to ChooseSymbol.");
                return RedirectToAction("ChooseSymbol");
            }

            var game = GetGameState();
            Console.WriteLine("✅ GameState Loaded Successfully");
            return View(game);
        }

        public IActionResult ChooseSymbol()
        {
            string gameMode = HttpContext.Session.GetString(GameModeKey) ?? "Unknown"; // Retrieve game mode from session
            ViewBag.GameMode = gameMode; // Pass it to the view

            Console.WriteLine($"🎮 ChooseSymbol: Game Mode - {gameMode}"); // Debugging
            return View();
        }
        public IActionResult GameMode()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SetGameMode(string mode)
        {
            if (string.IsNullOrEmpty(mode))
            {
                return RedirectToAction("Index"); // Prevent null values
            }

            HttpContext.Session.SetString(GameModeKey, mode); // Store game mode in session
            Console.WriteLine($"✅ Game Mode Set: {mode}"); // Debugging log
            return RedirectToAction("ChooseSymbol"); // Proceed to symbol selection
        }


        [HttpPost]
        public IActionResult SetSymbol(string symbol)
        {
            Console.WriteLine($"🔹 Symbol Chosen: {symbol}");

            if (symbol == "X" || symbol == "O")
            {
                HttpContext.Session.SetString(PlayerSymbolKey, symbol);

                // Set AI symbol to the opposite
                string aiSymbol = (symbol == "X") ? "O" : "X";
                HttpContext.Session.SetString(AIPlayerKey, aiSymbol);

                Console.WriteLine($"✅ Player symbol set to {symbol}, AI symbol set to {aiSymbol}");
                return RedirectToAction("Index");
            }

            Console.WriteLine("⚠️ Invalid symbol, redirecting back to ChooseSymbol");
            return RedirectToAction("ChooseSymbol");
        }

        public IActionResult MakeMove(int row, int col)
        {
            var game = GetGameState();
            string gameMode = HttpContext.Session.GetString(GameModeKey) ?? "Multiplayer"; // Default: Multiplayer
            string aiSymbol = HttpContext.Session.GetString(AIPlayerKey) ?? "O"; // Default AI symbol: O

            if (!game.IsGameOver && string.IsNullOrEmpty(game.Board[row][col]))
            {
                game.Board[row][col] = game.CurrentPlayer;
                Console.WriteLine($"🔹 Player {game.CurrentPlayer} made a move at [{row}, {col}]");

                if (game.CheckWin())
                {
                    game.IsGameOver = true;
                    UpdateScore(game.CurrentPlayer);
                    Console.WriteLine($"🎉 Player {game.CurrentPlayer} wins!");
                }
                else if (game.IsBoardFull())
                {
                    game.IsGameOver = true; // It's a draw
                    Console.WriteLine("🤝 It's a draw!");
                }
                else
                {
                    game.SwitchPlayer();
                    Console.WriteLine($"🔄 Switching player to: {game.CurrentPlayer}");

                    // If AI mode and it's AI's turn, let AI move
                    if (gameMode == "AI" && game.CurrentPlayer == aiSymbol)
                    {
                        Console.WriteLine("🤖 AI's Turn...");
                        MakeAIMove(game);
                    }
                }

                SaveGameState(game);
            }

            return RedirectToAction("Index");
        }

        private void MakeAIMove(GameModel game)
        {
            var random = new Random();
            var emptyCells = game.Board
                .SelectMany((row, rowIndex) => row.Select((cell, colIndex) => new { rowIndex, colIndex, cell }))
                .Where(c => string.IsNullOrEmpty(c.cell))
                .ToList();

            if (emptyCells.Count > 0)
            {
                var move = emptyCells[random.Next(emptyCells.Count)];
                string aiSymbol = HttpContext.Session.GetString(AIPlayerKey) ?? "O";

                game.Board[move.rowIndex][move.colIndex] = aiSymbol;
                Console.WriteLine($"🤖 AI ({aiSymbol}) moved at [{move.rowIndex}, {move.colIndex}]");

                // Check AI's move for win condition
                if (game.CheckWin())
                {
                    game.IsGameOver = true;
                    UpdateScore(aiSymbol);
                    Console.WriteLine($"🎉 AI ({aiSymbol}) wins!");
                }
                else if (game.IsBoardFull())
                {
                    game.IsGameOver = true; // Draw
                    Console.WriteLine("🤝 AI Move resulted in a draw!");
                }
                else
                {
                    game.SwitchPlayer(); // Back to human player
                    Console.WriteLine("🔄 Switching back to Human Player");
                }

                SaveGameState(game);
            }
        }

        public IActionResult Restart()
        {
            var playerSymbol = HttpContext.Session.GetString(PlayerSymbolKey) ?? "X";
            var aiSymbol = (playerSymbol == "X") ? "O" : "X"; // AI should be the opposite symbol

            var game = new GameModel(playerSymbol, aiSymbol)
            {
                PlayerXScore = HttpContext.Session.GetInt32(ScoreKeyX) ?? 0,
                PlayerOScore = HttpContext.Session.GetInt32(ScoreKeyO) ?? 0
            };

            SaveGameState(game);
            return RedirectToAction("Index");
        }

        private GameModel GetGameState()
        {
            var json = HttpContext.Session.GetString(SessionKey);
            if (!string.IsNullOrEmpty(json))
            {
                var game = JsonSerializer.Deserialize<GameModel>(json);
                if (game != null)
                {
                    return game;
                }
            }

            var playerSymbol = HttpContext.Session.GetString(PlayerSymbolKey) ?? "X";
            var aiSymbol = (playerSymbol == "X") ? "O" : "X"; // Default AI to opposite symbol

            var newGame = new GameModel(playerSymbol, aiSymbol)
            {
                PlayerXScore = HttpContext.Session.GetInt32(ScoreKeyX) ?? 0,
                PlayerOScore = HttpContext.Session.GetInt32(ScoreKeyO) ?? 0
            };

            SaveGameState(newGame);
            return newGame;
        }

        private void SaveGameState(GameModel game)
        {
            HttpContext.Session.SetString(SessionKey, JsonSerializer.Serialize(game));
        }

        private void UpdateScore(string winner)
        {
            if (winner == "X")
            {
                int scoreX = (HttpContext.Session.GetInt32(ScoreKeyX) ?? 0) + 1;
                HttpContext.Session.SetInt32(ScoreKeyX, scoreX);
            }
            else if (winner == "O")
            {
                int scoreO = (HttpContext.Session.GetInt32(ScoreKeyO) ?? 0) + 1;
                HttpContext.Session.SetInt32(ScoreKeyO, scoreO);
            }
        }
    }
}
