﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TicTacToe_SeanDorio.Models
{
    public class GameModel
    {
        public List<List<string>> Board { get; set; }
        public string CurrentPlayer { get; set; }
        public bool IsGameOver { get; set; }
        public string? Winner { get; set; }
        public int PlayerXScore { get; set; }
        public int PlayerOScore { get; set; }
        public string AIPlayer { get; set; } // Ensure AIPlayer exists

        // ✅ Constructor with default AI player
        public GameModel(string startingPlayer, string aiPlayer = "O")
        {
            CurrentPlayer = startingPlayer;
            AIPlayer = aiPlayer;
            IsGameOver = false;
            Winner = null;
            PlayerXScore = 0;
            PlayerOScore = 0;

            Board = new List<List<string>>
        {
            new List<string> { "", "", "" },
            new List<string> { "", "", "" },
            new List<string> { "", "", "" }
        };
        }

        // ✅ Default Constructor (for deserialization)
        public GameModel() : this("X", "O") { }

        public bool CheckWin()
        {
            return CheckWinForPlayer(CurrentPlayer);
        }

        public bool CheckWinForPlayer(string player)
        {
            for (int i = 0; i < 3; i++)
            {
                if (Board[i][0] == player && Board[i][1] == player && Board[i][2] == player ||
                    Board[0][i] == player && Board[1][i] == player && Board[2][i] == player)
                {
                    Winner = player;
                    return true;
                }
            }

            if (Board[0][0] == player && Board[1][1] == player && Board[2][2] == player ||
                Board[0][2] == player && Board[1][1] == player && Board[2][0] == player)
            {
                Winner = player;
                return true;
            }

            return false;
        }

        public bool IsBoardFull()
        {
            return Board.All(row => row.All(cell => !string.IsNullOrEmpty(cell)));
        }

        public void SwitchPlayer()
        {
            CurrentPlayer = (CurrentPlayer == "X") ? "O" : "X";
        }
        public void SetGameOver(bool gameOver)
        {
            IsGameOver = gameOver;
        }


        public List<(int row, int col)> GetEmptyCells()
        {
            var emptyCells = new List<(int, int)>();

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (string.IsNullOrEmpty(Board[i][j]))
                    {
                        emptyCells.Add((i, j));
                    }
                }
            }
            return emptyCells;
        }
    }
}
